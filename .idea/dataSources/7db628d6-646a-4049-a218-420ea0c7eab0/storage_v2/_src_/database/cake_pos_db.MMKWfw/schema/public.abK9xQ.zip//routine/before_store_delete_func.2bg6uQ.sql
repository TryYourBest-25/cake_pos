create function before_store_delete_func() returns trigger
    language plpgsql
as
$$
DECLARE
    store_count INT;
BEGIN
    SELECT COUNT(*) INTO store_count FROM store;
    IF store_count = 1 THEN
        RAISE EXCEPTION 'Không thể xóa thông tin cửa hàng duy nhất. Cửa hàng phải luôn có thông tin.' USING ERRCODE = '45000';
    END IF;
    RETURN OLD;
END;
$$;

alter function before_store_delete_func() owner to cake_user;

