create function before_membership_insert_check_expiration_func() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Nếu cập nhật valid_until, đảm bảo phải là ngày trong tương lai
    IF NEW.valid_until IS NOT NULL AND NEW.valid_until <= CURRENT_DATE THEN
        RAISE EXCEPTION 'Thời hạn membership phải là ngày trong tương lai' USING ERRCODE = '45000';
    END IF;
    RETURN NEW;
END;
$$;

alter function before_membership_insert_check_expiration_func() owner to "user";

