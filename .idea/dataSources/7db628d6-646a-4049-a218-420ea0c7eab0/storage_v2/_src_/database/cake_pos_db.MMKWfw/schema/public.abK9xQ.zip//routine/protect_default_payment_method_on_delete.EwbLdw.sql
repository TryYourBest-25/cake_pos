create function protect_default_payment_method_on_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.payment_name IN ('CASH', 'VNPAY') THEN
        RAISE EXCEPTION 'Không thể xóa phương thức thanh toán mặc định' USING ERRCODE = '45000';
    END IF;
    RETURN OLD;
END;
$$;

alter function protect_default_payment_method_on_delete() owner to cake_user;

