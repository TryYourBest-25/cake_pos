create function protect_payment_status_delete() returns trigger
    language plpgsql
as
$$
DECLARE
    newmem_id SMALLINT;
    updated_customers_count INT;
    updated_membership_types_count INT;
BEGIN
    -- Lấy ID của loại thành viên NEWMEM
    SELECT mt.membership_type_id
    INTO newmem_id
    FROM membership_type mt
    WHERE mt.type = 'NEWMEM'
    LIMIT 1; -- Đảm bảo chỉ lấy 1 nếu có trùng (dù 'type' là unique)

    IF newmem_id IS NULL THEN
        RAISE NOTICE 'Không tìm thấy loại thành viên NEWMEM.';
        RETURN;
    END IF;

    -- Tìm và cập nhật các khách hàng có loại thành viên đã hết hạn
    UPDATE customer c
    SET membership_type_id = newmem_id,
        current_points     = 0,
        updated_at         = CURRENT_TIMESTAMP
    FROM membership_type mt
    WHERE c.membership_type_id = mt.membership_type_id
      AND mt.valid_until IS NOT NULL
      AND mt.valid_until < CURRENT_DATE
      AND mt.type != 'NEWMEM'; -- Không reset nếu đã là NEWMEM
    GET DIAGNOSTICS updated_customers_count = ROW_COUNT;

    -- Log kết quả
    RAISE NOTICE 'Đã reset % khách hàng về loại thành viên NEWMEM do hết hạn', updated_customers_count;

    -- Tự động cập nhật valid_until về sau 1 năm cho các membership type (ngoại trừ NEWMEM) đã hết hạn
    -- Logic này có vẻ lạ: gia hạn cho *loại* thành viên, không phải cho từng khách hàng.
    -- Nếu ý là gia hạn cho các khách hàng vừa bị reset thì cần logic khác.
    -- Giả sử là gia hạn cho các membership_type definitions.
    UPDATE membership_type mt
    SET valid_until = CURRENT_DATE + INTERVAL '1 year'
    WHERE mt.valid_until IS NOT NULL
      AND mt.valid_until < CURRENT_DATE
      AND mt.type != 'NEWMEM'; -- NEWMEM thường không có valid_until hoặc không nên tự động gia hạn theo cách này
    GET DIAGNOSTICS updated_membership_types_count = ROW_COUNT;

    -- Log kết quả cập nhật thời hạn
    RAISE NOTICE 'Đã cập nhật thời hạn cho % loại thành viên thêm 1 năm', updated_membership_types_count;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Lỗi xảy ra trong sp_reset_expired_memberships: % - %', SQLSTATE, SQLERRM;
        -- Không có ROLLBACK rõ ràng ở đây vì PL/pgSQL procedure chạy trong một transaction
        -- Nếu có lỗi, toàn bộ procedure sẽ rollback trừ khi có sub-transaction.
END;
$$;

alter function protect_payment_status_delete() owner to "user";

