create function before_store_update_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.store_id IS DISTINCT FROM OLD.store_id THEN
        RAISE EXCEPTION 'Không thể thay đổi ID của cửa hàng. Chỉ được phép cập nhật thông tin.' USING ERRCODE = '45000';
    END IF;
    RETURN NEW;
END;
$$;

alter function before_store_update_func() owner to cake_user;

