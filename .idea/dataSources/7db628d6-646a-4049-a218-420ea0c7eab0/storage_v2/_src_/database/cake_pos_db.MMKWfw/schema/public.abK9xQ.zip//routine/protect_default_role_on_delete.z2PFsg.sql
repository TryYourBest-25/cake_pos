create function protect_default_role_on_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.name IN ('MANAGER', 'STAFF', 'CUSTOMER', 'GUEST') THEN
        RAISE EXCEPTION 'Không thể xóa vai trò mặc định' USING ERRCODE = '45000';
    END IF;
    RETURN OLD;
END;
$$;

alter function protect_default_role_on_delete() owner to cake_user;

