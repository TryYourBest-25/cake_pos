create function protect_default_role_on_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.name IN ('MANAGER', 'STAFF', 'CUSTOMER', 'GUEST') THEN
        IF NEW.name IS DISTINCT FROM OLD.name THEN
            RAISE EXCEPTION 'Không thể thay đổi tên vai trò mặc định' USING ERRCODE = '45000';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function protect_default_role_on_update() owner to cake_user;

