create function before_store_insert_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.payment_name IN ('CASH', 'VNPAY') THEN
        RAISE EXCEPTION 'Không thể xóa phương thức thanh toán mặc định' USING ERRCODE = '45000';
    END IF;
    RETURN OLD;
END;
$$;

alter function before_store_insert_func() owner to "user";

