create function before_store_insert_func() returns trigger
    language plpgsql
as
$$
DECLARE
    store_count INT;
BEGIN
    SELECT COUNT(*) INTO store_count FROM store;
    IF store_count > 0 THEN
        RAISE EXCEPTION 'Không thể tạo thêm thông tin cửa hàng mới. Chỉ được phép có một bản ghi thông tin cửa hàng.' USING ERRCODE = '45000';
    END IF;
    RETURN NEW;
END;
$$;

alter function before_store_insert_func() owner to cake_user;

