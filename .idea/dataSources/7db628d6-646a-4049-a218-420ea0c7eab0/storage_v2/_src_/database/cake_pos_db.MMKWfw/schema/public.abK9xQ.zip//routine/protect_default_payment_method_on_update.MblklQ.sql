create function protect_default_payment_method_on_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.payment_name IN ('CASH', 'VNPAY') THEN
        IF NEW.payment_name IS DISTINCT FROM OLD.payment_name THEN
            RAISE EXCEPTION 'Không thể thay đổi tên phương thức thanh toán mặc định' USING ERRCODE = '45000';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function protect_default_payment_method_on_update() owner to cake_user;

