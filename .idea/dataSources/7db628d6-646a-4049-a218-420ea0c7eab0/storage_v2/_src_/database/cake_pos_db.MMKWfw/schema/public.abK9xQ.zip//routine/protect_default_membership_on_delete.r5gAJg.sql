create function protect_default_membership_on_delete() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.type IN ('NEWMEM', 'BRONZE', 'SILVER', 'GOLD', 'PLATINUM') THEN
        RAISE EXCEPTION 'Không thể xóa loại thành viên mặc định' USING ERRCODE = '45000';
    END IF;
    RETURN OLD;
END;
$$;

alter function protect_default_membership_on_delete() owner to cake_user;

