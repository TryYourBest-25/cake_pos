create function protect_order_discount_insert() returns trigger
    language plpgsql
as
$$
DECLARE
    order_status_val order_status_enum;
BEGIN
    -- Lấy trạng thái đơn hàng
    SELECT status INTO order_status_val FROM "order" WHERE order_id = NEW.order_id;
    
    -- Kiểm tra nếu đơn hàng đã bị hủy hoặc hoàn thành
    IF order_status_val IN ('CANCELLED', 'COMPLETED') THEN
        RAISE EXCEPTION 'Không thể áp dụng giảm giá cho đơn hàng đã hủy hoặc hoàn thành' USING ERRCODE = '45000';
    END IF;
    
    RETURN NEW;
END;
$$;

alter function protect_order_discount_insert() owner to "user";

