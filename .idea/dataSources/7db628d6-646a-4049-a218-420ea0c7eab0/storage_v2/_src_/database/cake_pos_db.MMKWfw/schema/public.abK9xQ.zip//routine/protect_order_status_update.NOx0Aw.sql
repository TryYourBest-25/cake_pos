create function protect_order_status_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.store_id IS DISTINCT FROM OLD.store_id THEN
        RAISE EXCEPTION 'Không thể thay đổi ID của cửa hàng. Chỉ được phép cập nhật thông tin.' USING ERRCODE = '45000';
    END IF;
    RETURN NEW;
END;
$$;

alter function protect_order_status_update() owner to "user";

