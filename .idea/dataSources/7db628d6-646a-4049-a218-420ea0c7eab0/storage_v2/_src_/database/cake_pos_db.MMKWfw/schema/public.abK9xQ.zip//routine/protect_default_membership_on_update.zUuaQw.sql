create function protect_default_membership_on_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.type IN ('NEWMEM', 'BRONZE', 'SILVER', 'GOLD', 'PLATINUM') THEN
        IF NEW.type IS DISTINCT FROM OLD.type THEN
            RAISE EXCEPTION 'Không thể thay đổi tên loại thành viên mặc định' USING ERRCODE = '45000';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function protect_default_membership_on_update() owner to cake_user;

