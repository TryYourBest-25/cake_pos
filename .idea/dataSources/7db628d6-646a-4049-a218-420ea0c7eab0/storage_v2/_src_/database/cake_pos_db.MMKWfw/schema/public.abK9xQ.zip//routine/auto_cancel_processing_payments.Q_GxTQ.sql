create function auto_cancel_processing_payments() returns trigger
    language plpgsql
as
$$
DECLARE
    store_count INT;
BEGIN
    SELECT COUNT(*) INTO store_count FROM store;
    IF store_count = 1 THEN
        RAISE EXCEPTION 'Không thể xóa thông tin cửa hàng duy nhất. Cửa hàng phải luôn có thông tin.' USING ERRCODE = '45000';
    END IF;
    RETURN OLD;
END;
$$;

alter function auto_cancel_processing_payments() owner to "user";

