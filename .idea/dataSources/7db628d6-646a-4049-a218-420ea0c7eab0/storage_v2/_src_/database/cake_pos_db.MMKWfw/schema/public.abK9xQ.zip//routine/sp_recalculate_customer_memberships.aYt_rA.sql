create procedure sp_recalculate_customer_memberships()
    language plpgsql
as
$$
DECLARE
    updated_customers_count INT;
BEGIN
    -- Cập nhật loại thành viên dựa trên điểm hiện tại
    UPDATE customer c
    SET membership_type_id = sub.new_membership_type_id,
        updated_at         = CURRENT_TIMESTAMP
    FROM (
        SELECT 
            c_inner.customer_id,
            (SELECT mt.membership_type_id
             FROM membership_type mt
             WHERE c_inner.current_points >= mt.required_point
               AND (mt.valid_until IS NULL OR mt.valid_until > CURRENT_DATE)
               AND mt.is_active = TRUE -- Chỉ xét các loại thành viên đang active
             ORDER BY mt.required_point DESC
             LIMIT 1) as new_membership_type_id
        FROM customer c_inner
        WHERE c_inner.current_points > 0
    ) AS sub
    WHERE c.customer_id = sub.customer_id AND c.membership_type_id IS DISTINCT FROM sub.new_membership_type_id;

    GET DIAGNOSTICS updated_customers_count = ROW_COUNT;
    -- Log kết quả
    RAISE NOTICE 'Đã tái cấp loại thành viên cho % khách hàng dựa trên điểm hiện tại', updated_customers_count;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Lỗi xảy ra trong sp_recalculate_customer_memberships: % - %', SQLSTATE, SQLERRM;
END;
$$;

alter procedure sp_recalculate_customer_memberships() owner to cake_user;

