create function protect_order_product_update() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Ghi log bắt đầu (Tùy chọn)
    -- RAISE NOTICE 'Bắt đầu sp_deactivate_expired_discounts lúc %', NOW();

    UPDATE discount
    SET is_active = false, -- Sử dụng false cho kiểu BOOLEAN của PostgreSQL
        updated_at = CURRENT_TIMESTAMP
    WHERE is_active = true -- Chỉ cập nhật những cái đang active
      AND valid_until < CURRENT_DATE; -- CURDATE() của MySQL tương đương CURRENT_DATE của PostgreSQL

    -- Ghi log kết thúc (Tùy chọn)
    -- RAISE NOTICE 'Kết thúc sp_deactivate_expired_discounts lúc %', NOW();

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Lỗi xảy ra trong sp_deactivate_expired_discounts: % - %', SQLSTATE, SQLERRM;
END;
$$;

alter function protect_order_product_update() owner to "user";

